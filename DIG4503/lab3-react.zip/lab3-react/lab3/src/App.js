import React from 'react';
import HomePage from './components/homepage'

function App() {
  const fname = 'Alyssa';
  return (
    <HomePage firstname={fname} />
  ) 
}

export default App;
